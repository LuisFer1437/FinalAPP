const express = require("express")
const mysql = require("mysql2")
const bodyParser = require("body-parser")

const app = express()
const PUERTO = 3000

app.use(bodyParser.json())

const conexion = mysql.createConnection(
    {
        host:'localhost',
        database:'bdproyectoapp',
        user:'root',
        password:'RT1437365lmm',
        port:3306
    }
)

app.listen(PUERTO, ()=>{
    console.log("Servidor esta corriendo en el puerto "+PUERTO)
})

conexion.connect(error=>{
    if(error) throw error
    console.log("Base de datos conectada")
})

app.get("/",(req,res)=>{
    res.send("Bienvenido a mi servicio web en node")
})

app.get("/medicos",(req,res)=>{
    const consulta = "SELECT * FROM medicos"
    conexion.query(consulta, (error,rpta)=>{
        if(error) return console.error(error.message)
        
        const obj = {}
        if(rpta.length > 0){
            obj.listaMedicos = rpta
            res.json(obj)
        }else{
            re.json("No hay registros")
        }
    })
})

app.get("/mostrarCita",(req,res)=>{
    const consulta = "SELECT * FROM cita"
    conexion.query(consulta, (error,rpta)=>{
        if(error) return console.error(error.message)
        
        const obj = {}
        if(rpta.length > 0){
            obj.listaCitas = rpta
            res.json(obj)
        }else{
            res.json("No hay registros")
        }
    })
})


app.post("/cita", (req, res) => {
    const { citaFecha, citaHora, nombreMedico, especialidadMedico } = req.body;

    // Validar los datos antes de insertarlos
    if (!citaFecha || !citaHora || !nombreMedico || !especialidadMedico) {
        return res.status(400).json({ message: "Todos los campos son requeridos" });
    }

    // Consulta SQL para insertar una nueva cita
    const consulta = "INSERT INTO cita (citaFecha, citaHora, nombreMedico, especialidadMedico) VALUES (?, ?, ?, ?)";

    conexion.query(consulta, [citaFecha, citaHora, nombreMedico, especialidadMedico], (error, result) => {
        if (error) {
            console.error(error.message);
            return res.status(500).json({ message: "Error al insertar la cita" });
        }
        res.status(201).json({ message: "Cita agregada exitosamente", idCita: result.insertId });
    });
});

app.delete("/eliminarcita/:id", (req, res) => {
    const { id } = req.params;
    const consulta = "DELETE FROM cita WHERE idcita=?";
    conexion.query(consulta, [id], (error) => {
        if (error) {
            console.error(error.message);
            return res.status(500).json({ message: "Error al eliminar la cita" });
        }
        res.json({ message: "Cita eliminada correctamente" });
    });
});


